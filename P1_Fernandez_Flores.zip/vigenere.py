# -*- coding: utf-8 -*-
"""
Created on Sat Sep 26 20:09:06 2026

@author: marco
"""

def encrypt(plaintext: str, key: str) -> str:
    if len(key) == 0:
        raise ValueError
    if not all('A' <= caracter <= 'Z' for caracter in key):
        raise ValueError

    lenght=len(plaintext)
    answer=""
    for i in range(0, lenght):
        answer += chr(((ord(plaintext[i])-65 + ord(key[i % len(key)]) -65) % 26)+65)
    return answer



def decrypt(ciphertext: str, key: str) -> str:
    if len(key) == 0:
        raise ValueError
    if not all('A' <= caracter <= 'Z' for caracter in key):
        raise ValueError
    
    lenght=len(ciphertext)
    answer=""
    for i in range(0, lenght):
        answer += chr(((ord(ciphertext[i]) - ord(key[i % len(key)])) % 26)+65)
    return answer
    
#-6%26=20, decrypt igual que en el encrypt pero restando, y no hace falta restar 65 a ambos pq es un sinsentido al ser resta
    
def cosets(ciphertext: str, m: int) -> list[str]:
    lenght=len(ciphertext)
    sol_list=[]
    for i in range(0, m):
        letters = ciphertext[i::m]
        sol_list.append(letters)
    return sol_list
